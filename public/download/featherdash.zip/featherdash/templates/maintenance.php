<?php
/**
 * Maintenance page, rendered by DigitalBrew\Featherdash\Modules\Maintenance.
 *
 * Its styles are the `featherdash-maintenance` stylesheet, registered by the
 * module with the colours and background as inline custom properties.
 *
 * @var array{title: string, subtitle: string, body: string, background: string, text: string, image: string, site: string, lang: string, charset: string, icon: string} $view
 */

declare(strict_types=1);

defined('ABSPATH') || exit;

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php echo esc_attr($view['charset']); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title><?php echo esc_html($view['title'] . ($view['site'] !== '' && $view['site'] !== $view['title'] ? ' – ' . $view['site'] : '')); ?></title>
    <?php if ($view['icon'] !== '') : ?>
        <link rel="icon" href="<?php echo esc_url($view['icon']); ?>">
    <?php endif; ?>
    <?php wp_print_styles('featherdash-maintenance'); ?>
</head>
<body class="fd-maintenance">
    <main>
        <h1><?php echo esc_html($view['title']); ?></h1>
        <?php if ($view['subtitle'] !== '') : ?>
            <p class="subtitle"><?php echo esc_html($view['subtitle']); ?></p>
        <?php endif; ?>
        <?php if ($view['body'] !== '') : ?>
            <div class="body"><?php echo wp_kses_post($view['body']); ?></div>
        <?php endif; ?>
    </main>
</body>
</html>
