<?php

declare (strict_types = 1);
namespace DigitalBrew\Featherdash\Settings;

use DigitalBrew\Featherdash\Licensing\Licensing;
use DigitalBrew\Featherdash\Licensing\Pro;
/**
 * The About tab of Settings → FeatherDash (what it is, Free and Pro, where the
 * documentation is, what's new) and the per-tab documentation links. Both
 * stay out of a white-labelled admin.
 */
final class About {
    /** Online documentation; one page per settings tab. */
    public const DOCS_URL = 'https://featherdash.io/docs/';

    private const SUPPORT_URL = 'https://wordpress.org/support/plugin/featherdash/';

    /** Settings tab => documentation page. */
    private const TAB_DOCS = [
        'appearance'   => 'appearance',
        'menu-builder' => 'menu-builder',
        'toolbar'      => 'toolbar',
        'dashboard'    => 'dashboard',
        'content'      => 'content-and-tables',
        'cleanup'      => 'admin-cleanup',
        'frontend'     => 'front-end',
        'security'     => 'security',
        'login'        => 'login',
        'maintenance'  => 'maintenance',
        'analytics'    => 'analytics',
        'whitelabel'   => 'white-label',
        'site'         => 'site-identity',
        'tools'        => 'tools',
    ];

    private Settings $settings;

    public function __construct( Settings $settings ) {
        $this->settings = $settings;
    }

    /**
     * Off in a white-labelled admin: clients shouldn't land on a product page.
     */
    public function visible() : bool {
        $visible = true;
        return $visible;
    }

    /**
     * A documentation page ('' for the index).
     */
    public static function docsUrl( string $page = '' ) : string {
        $url = self::DOCS_URL . (( $page !== '' ? trailingslashit( $page ) : '' ));
        /**
         * Filters a documentation link on the settings screen.
         *
         * @param string $url  The link.
         * @param string $page The page slug ('' for the index).
         */
        return (string) apply_filters( 'featherdash/docs_url', $url, $page );
    }

    /**
     * "Docs" link at the top of a settings tab.
     */
    public function tabLink( string $tab ) : void {
        if ( !$this->visible() || !isset( self::TAB_DOCS[$tab] ) ) {
            return;
        }
        printf(
            '<p class="fd-panel-docs"><a href="%s" target="_blank" rel="noopener"><span class="dashicons dashicons-book-alt" aria-hidden="true"></span>%s<span class="screen-reader-text"> %s</span></a></p>',
            esc_url( self::docsUrl( self::TAB_DOCS[$tab] ) ),
            esc_html__( 'Docs', 'featherdash' ),
            esc_html__( '(opens in a new tab)', 'featherdash' )
        );
    }

    /**
     * @param array<string, array<string, mixed>> $sections Schema::sections().
     */
    public function render( array $sections, callable $proCard ) : void {
        if ( !$this->visible() ) {
            return;
        }
        ?>
        <section class="fd-panel fd-about" id="fd-panel-about" role="tabpanel" data-tab="about" data-standalone>
            <?php 
        $this->renderIntro();
        ?>
            <?php 
        $proCard();
        ?>
            <?php 
        ?>
            <?php 
        $this->renderDocs( $sections );
        ?>
            <?php 
        $this->renderNews();
        ?>
        </section>
        <?php 
    }

    private function renderIntro() : void {
        $plan = __( 'Free', 'featherdash' );
        $intro = __( 'FeatherDash gives wp-admin a calm, modern look and clears out what your clients don\'t need: a new admin theme, a tidier toolbar and dashboard, cleaner list tables, a branded login and maintenance screen, and the Google tag with Consent Mode.', 'featherdash' );
        $support = self::SUPPORT_URL;
        $account = '';
        $links = [['dashicons-book-alt', __( 'Documentation', 'featherdash' ), self::docsUrl()], ['dashicons-list-view', __( 'Changelog', 'featherdash' ), self::docsUrl( 'changelog' )]];
        // Agency sites are supported by the agency itself.
        if ( !Licensing::agency() ) {
            $links[] = ['dashicons-sos', __( 'Support', 'featherdash' ), $support];
            if ( $account !== '' ) {
                $links[] = ['dashicons-admin-users', __( 'Account and licence', 'featherdash' ), $account];
            }
        }
        ?>
        <div class="fd-card fd-about-intro">
            <h2 class="fd-card-title"><?php 
        esc_html_e( 'About FeatherDash', 'featherdash' );
        ?></h2>
            <p class="fd-card-desc"><?php 
        echo esc_html( $intro );
        ?></p>
            <dl class="fd-about-meta">
                <div><dt><?php 
        esc_html_e( 'Version', 'featherdash' );
        ?></dt><dd><?php 
        echo esc_html( FEATHERDASH_VERSION );
        ?></dd></div>
                <div><dt><?php 
        esc_html_e( 'Plan', 'featherdash' );
        ?></dt><dd><?php 
        echo esc_html( $plan );
        ?></dd></div>
                <div><dt><?php 
        esc_html_e( 'Made by', 'featherdash' );
        ?></dt><dd><a href="https://digitalbrew.io" target="_blank" rel="noopener">DigitalBrew</a></dd></div>
            </dl>
            <p class="fd-about-links">
                <?php 
        foreach ( $links as [$icon, $label, $url] ) {
            ?>
                    <?php 
            if ( $url === '' ) {
                continue;
            }
            ?>
                    <a class="button" href="<?php 
            echo esc_url( $url );
            ?>" target="_blank" rel="noopener"><span class="dashicons <?php 
            echo esc_attr( $icon );
            ?>" aria-hidden="true"></span><?php 
            echo esc_html( $label );
            ?></a>
                <?php 
        }
        ?>
            </p>
        </div>
        <?php 
    }

    /**
     * @param array<string, array<string, mixed>> $sections
     */
    private function renderDocs( array $sections ) : void {
        $tabs = [];
        foreach ( $sections as $key => $section ) {
            $tabs[(string) $key] = [(string) ($section['icon'] ?? ''), (string) $section['label']];
            if ( $key === 'appearance' ) {
                $tabs['menu-builder'] = ['dashicons-menu-alt', __( 'Menu builder', 'featherdash' )];
            }
        }
        $tabs['tools'] = ['dashicons-admin-tools', __( 'Tools', 'featherdash' )];
        $guides = [
            ['dashicons-flag', __( 'Getting started', 'featherdash' ), 'getting-started'],
            ['dashicons-editor-help', __( 'FAQ', 'featherdash' ), 'faq'],
            ['dashicons-admin-plugins', __( 'Plugin compatibility', 'featherdash' ), 'compatibility'],
            ['dashicons-editor-code', __( 'Developers: hooks and constants', 'featherdash' ), 'developers']
        ];
        ?>
        <div class="fd-card fd-about-docs">
            <h2 class="fd-card-title"><?php 
        esc_html_e( 'Documentation', 'featherdash' );
        ?></h2>
            <p class="fd-card-desc"><?php 
        esc_html_e( 'Every setting explained, one page per tab. Each tab also has a Docs link at the top.', 'featherdash' );
        ?></p>
            <ul class="fd-about-doclist fd-about-doclist--guides">
                <?php 
        foreach ( $guides as [$icon, $label, $page] ) {
            ?>
                    <li><a href="<?php 
            echo esc_url( self::docsUrl( $page ) );
            ?>" target="_blank" rel="noopener"><span class="dashicons <?php 
            echo esc_attr( $icon );
            ?>" aria-hidden="true"></span><?php 
            echo esc_html( $label );
            ?></a></li>
                <?php 
        }
        ?>
            </ul>
            <ul class="fd-about-doclist">
                <?php 
        foreach ( $tabs as $key => [$icon, $label] ) {
            ?>
                    <?php 
            if ( !isset( self::TAB_DOCS[$key] ) ) {
                continue;
            }
            ?>
                    <li><a href="<?php 
            echo esc_url( self::docsUrl( self::TAB_DOCS[$key] ) );
            ?>" target="_blank" rel="noopener"><span class="dashicons <?php 
            echo esc_attr( $icon );
            ?>" aria-hidden="true"></span><?php 
            echo esc_html( $label );
            ?></a></li>
                <?php 
        }
        ?>
            </ul>
        </div>
        <?php 
    }

    /**
     * The first entries of the latest version in CHANGELOG.md.
     */
    private function renderNews() : void {
        [$version, $items] = self::latestChanges( 6 );
        if ( $items === [] ) {
            return;
        }
        ?>
        <div class="fd-card fd-about-news">
            <h2 class="fd-card-title"><?php 
        /* translators: %s: version number */
        echo esc_html( sprintf( __( 'What\'s new in %s', 'featherdash' ), $version ) );
        ?></h2>
            <ul class="fd-about-newslist">
                <?php 
        foreach ( $items as [$title, $text] ) {
            ?>
                    <li>
                        <?php 
            if ( $title !== '' ) {
                ?><strong><?php 
                echo esc_html( $title );
                ?></strong> <?php 
            }
            ?>
                        <?php 
            echo esc_html( $text );
            ?>
                    </li>
                <?php 
        }
        ?>
            </ul>
            <p><a href="<?php 
        echo esc_url( self::docsUrl( 'changelog' ) );
        ?>" target="_blank" rel="noopener"><?php 
        esc_html_e( 'Full changelog', 'featherdash' );
        ?></a></p>
        </div>
        <?php 
    }

    /**
     * @return array{0: string, 1: array<int, array{0: string, 1: string}>}
     */
    private static function latestChanges( int $limit ) : array {
        $file = FEATHERDASH_DIR . 'CHANGELOG.md';
        if ( !is_readable( $file ) ) {
            return ['', []];
        }
        $version = '';
        $items = [];
        foreach ( (array) file( $file, FILE_IGNORE_NEW_LINES ) as $line ) {
            $line = (string) $line;
            if ( preg_match( '/^## \\[([^\\]]+)\\]/', $line, $match ) ) {
                if ( $version !== '' ) {
                    break;
                }
                $version = $match[1];
                continue;
            }
            if ( $version === '' || !str_starts_with( $line, '- ' ) ) {
                continue;
            }
            $text = substr( $line, 2 );
            $title = '';
            // "**Name** (where): description" → a bold name and the description.
            if ( preg_match( '/^\\*\\*(.+?)\\*\\*(?:\\s*\\([^)]*\\))?[:.]?\\s*(.*)$/', $text, $match ) ) {
                $title = self::plain( $match[1] );
                $text = $match[2];
            }
            $items[] = [$title, wp_trim_words( self::plain( $text ), 24 )];
            if ( count( $items ) >= $limit ) {
                break;
            }
        }
        return [$version, $items];
    }

    /**
     * Markdown inline formatting to plain text.
     */
    private static function plain( string $text ) : string {
        $text = (string) preg_replace( '/\\[([^\\]]+)\\]\\([^)]*\\)/', '$1', $text );
        return trim( str_replace( ['**', '`', '*'], '', $text ) );
    }

}
