<?php

declare (strict_types = 1);
namespace DigitalBrew\Featherdash\Settings;

use DigitalBrew\Featherdash\Licensing\Licensing;
use DigitalBrew\Featherdash\Licensing\Pro;
/**
 * Renders the Settings → FeatherDash screen and handles import/reset.
 */
final class SettingsPage {
    /** First time the settings page was opened (for the review request). */
    public const INSTALLED_OPTION = 'featherdash_installed';

    /** Set once a user answered the review request. */
    private const REVIEW_META = 'featherdash_review_asked';

    private const REVIEW_URL = 'https://wordpress.org/support/plugin/featherdash/reviews/#new-post';

    private Settings $settings;

    public function __construct( Settings $settings ) {
        $this->settings = $settings;
    }

    public function register() : void {
        add_action( 'admin_menu', [$this, 'addPage'] );
        add_action( 'admin_init', [$this, 'registerSettings'] );
        add_action( 'admin_post_featherdash_import', [$this, 'importSettings'] );
        add_action( 'admin_post_featherdash_reset', [$this, 'resetSettings'] );
        add_action( 'admin_post_featherdash_review', [$this, 'review'] );
        add_filter(
            'script_loader_tag',
            [$this, 'moduleTag'],
            10,
            3
        );
        add_filter( 'plugin_action_links_' . plugin_basename( FEATHERDASH_FILE ), [$this, 'actionLinks'] );
    }

    public function addPage() : void {
        $hook = add_options_page(
            __( 'FeatherDash', 'featherdash' ),
            __( 'FeatherDash', 'featherdash' ),
            'manage_options',
            'featherdash',
            [$this, 'render']
        );
        if ( is_string( $hook ) ) {
            add_action( 'load-' . $hook, [$this, 'onLoad'] );
        }
    }

    public function onLoad() : void {
        // When FeatherDash was first used, for the review request.
        add_option(
            self::INSTALLED_OPTION,
            time(),
            '',
            false
        );
        add_filter( 'admin_body_class', [$this, 'bodyClass'] );
        add_action( 'admin_enqueue_scripts', [$this, 'enqueue'] );
        add_action( 'admin_notices', [$this, 'maybeShowImportError'] );
    }

    public function registerSettings() : void {
        register_setting( 'featherdash', Settings::OPTION, [
            'type'              => 'array',
            'sanitize_callback' => [Settings::class, 'sanitize'],
            'default'           => [],
        ] );
    }

    public function bodyClass( string $classes ) : string {
        return $classes . ' fd-settings';
    }

    public function enqueue() : void {
        // Media library modal for image fields.
        wp_enqueue_media();
        if ( file_exists( FEATHERDASH_DIR . 'dist/settings.css' ) ) {
            wp_enqueue_style(
                'featherdash-settings',
                FEATHERDASH_URL . 'dist/settings.css',
                [],
                $this->version( 'dist/settings.css' )
            );
        }
        if ( file_exists( FEATHERDASH_DIR . 'dist/settings.js' ) ) {
            wp_enqueue_script(
                'featherdash-settings',
                FEATHERDASH_URL . 'dist/settings.js',
                [],
                $this->version( 'dist/settings.js' ),
                [
                    'in_footer' => true,
                    'strategy'  => 'defer',
                ]
            );
        }
    }

    /**
     * @param string $tag
     * @param string $handle
     * @param string $src
     */
    public function moduleTag( $tag, $handle, $src ) : string {
        if ( $handle !== 'featherdash-settings' && $handle !== 'featherdash-menu-builder' ) {
            return $tag;
        }
        $tag = preg_replace( '/\\stype=([\'"])[^\'"]*\\1/', '', $tag ) ?? $tag;
        return str_replace( '<script ', '<script type="module" ', $tag );
    }

    /**
     * @param array<int, string> $links
     *
     * @return array<int, string>
     */
    public function actionLinks( array $links ) : array {
        $url = admin_url( 'options-general.php?page=featherdash' );
        array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'featherdash' ) . '</a>' );
        return $links;
    }

    public function maybeShowImportError() : void {
        // Only picks which message to show, so no nonce.
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only: which error notice to show.
        $error = ( isset( $_GET['fd-error'] ) ? sanitize_key( wp_unslash( (string) $_GET['fd-error'] ) ) : '' );
        if ( $error === 'import' ) {
            echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__( 'The import could not be read. Please paste valid FeatherDash JSON.', 'featherdash' ) . '</p></div>';
        }
    }

    public function render() : void {
        if ( !current_user_can( 'manage_options' ) ) {
            return;
        }
        $sections = Schema::sections();
        $about = new About($this->settings);
        ?>
        <div class="wrap fd-settings-page">
            <header class="fd-settings-header">
                <h1><?php 
        esc_html_e( 'FeatherDash', 'featherdash' );
        ?></h1>
                <p class="fd-settings-version">v<?php 
        echo esc_html( FEATHERDASH_VERSION );
        ?></p>
            </header>
            <?php 
        // Core moves admin notices after .wp-header-end instead of into our flex header.
        ?>
            <hr class="wp-header-end">
            <div class="fd-settings-layout">
            <nav class="fd-tabs" role="tablist" aria-orientation="vertical">
                <?php 
        $isFirst = true;
        ?>
                <?php 
        foreach ( $sections as $key => $section ) {
            ?>
                    <a class="fd-tab<?php 
            echo ( $isFirst ? ' is-active' : '' );
            ?>"
                        href="#<?php 
            echo esc_attr( (string) $key );
            ?>"
                        role="tab"
                        aria-selected="<?php 
            echo ( $isFirst ? 'true' : 'false' );
            ?>"
                        data-tab="<?php 
            echo esc_attr( (string) $key );
            ?>"><?php 
            $this->tabIcon( (string) ($section['icon'] ?? '') );
            echo esc_html( (string) $section['label'] );
            ?></a>
                    <?php 
            ?>
                    <?php 
            $isFirst = false;
            ?>
                <?php 
        }
        ?>
                <a class="fd-tab" href="#tools" role="tab" aria-selected="false" data-tab="tools"><?php 
        $this->tabIcon( 'dashicons-admin-tools' );
        esc_html_e( 'Tools', 'featherdash' );
        ?></a>
                <?php 
        if ( $about->visible() ) {
            ?>
                    <a class="fd-tab" href="#about" role="tab" aria-selected="false" data-tab="about"><?php 
            $this->tabIcon( 'dashicons-info-outline' );
            esc_html_e( 'About', 'featherdash' );
            ?></a>
                <?php 
        }
        ?>
            </nav>
            <div class="fd-settings-main">
            <form method="post" action="options.php" class="fd-settings-form">
                <?php 
        settings_fields( 'featherdash' );
        ?>
                <?php 
        $isFirst = true;
        ?>
                <?php 
        foreach ( $sections as $key => $section ) {
            ?>
                    <section class="fd-panel<?php 
            echo ( $isFirst ? ' is-active' : '' );
            ?>"
                        id="fd-panel-<?php 
            echo esc_attr( (string) $key );
            ?>"
                        role="tabpanel"
                        data-tab="<?php 
            echo esc_attr( (string) $key );
            ?>">
                        <?php 
            $isFirst = false;
            ?>
                        <?php 
            $about->tabLink( (string) $key );
            ?>
                        <?php 
            foreach ( $section['cards'] as $card ) {
                ?>
                            <?php 
                if ( !$this->cardVisible( $card ) ) {
                    continue;
                }
                ?>
                            <?php 
                ?>
                            <div class="fd-card">
                                <h2 class="fd-card-title"><?php 
                echo esc_html( (string) $card['title'] );
                ?></h2>
                                <?php 
                if ( !empty( $card['desc'] ) ) {
                    ?>
                                    <p class="fd-card-desc"><?php 
                    echo esc_html( (string) $card['desc'] );
                    ?></p>
                                <?php 
                }
                ?>
                                <?php 
                if ( isset( $card['callback_before'] ) && is_callable( $card['callback_before'] ) ) {
                    call_user_func( $card['callback_before'] );
                }
                ?>
                                <?php 
                if ( isset( $card['callback'] ) ) {
                    if ( is_callable( $card['callback'] ) ) {
                        call_user_func( $card['callback'] );
                    }
                    echo '</div>';
                    continue;
                }
                ?>
                                <?php 
                foreach ( $card['fields'] as $field ) {
                    $this->renderField( $field );
                }
                ?>
                                <?php 
                if ( isset( $card['footer'] ) && is_callable( $card['footer'] ) ) {
                    ?>
                                    <div class="fd-card-footer"><?php 
                    call_user_func( $card['footer'] );
                    ?></div>
                                <?php 
                }
                ?>
                            </div>
                        <?php 
            }
            ?>
                    </section>
                <?php 
        }
        ?>
                <footer class="fd-settings-footer">
                    <?php 
        $this->renderReviewLink();
        ?>
                    <button type="submit" class="button button-primary"><?php 
        esc_html_e( 'Save changes', 'featherdash' );
        ?></button>
                </footer>
            </form>
            <?php 
        ?>
            <?php 
        $this->renderTools( $about );
        ?>
            <?php 
        $about->render( $sections, fn() => $this->renderProCard() );
        ?>
            </div>
            </div>
        </div>
        <?php 
    }

    private function tabIcon( string $icon ) : void {
        if ( $icon !== '' ) {
            echo '<span class="dashicons ' . esc_attr( $icon ) . '" aria-hidden="true"></span>';
        }
    }

    /**
     * @param array<string, mixed> $card
     */
    private function cardVisible( array $card ) : bool {
        $condition = $card['condition'] ?? null;
        return match ($condition) {
            'multisite' => is_multisite(),
            'woocommerce' => class_exists( 'WooCommerce' ),
            'not_agency' => !Licensing::agency(),
            default => true,
        };
    }

    /**
     * @param array<string, mixed> $field
     */
    private function renderField( array $field, bool $inLockedCard = false ) : void {
        $path = (string) $field['path'];
        $type = (string) $field['type'];
        // A field can read its value elsewhere and post under its own name
        // (e.g. the favicon, which is WordPress' own Site Icon option).
        $value = ( isset( $field['value'] ) && is_callable( $field['value'] ) ? call_user_func( $field['value'] ) : $this->settings->saved( $path ) );
        $id = $this->fieldId( $path );
        $name = ( isset( $field['name'] ) ? (string) $field['name'] : $this->fieldName( $path ) );
        $classes = 'fd-field fd-field--' . $type;
        $badge = '';
        $open = '<div class="fd-field-control">';
        $close = '</div>';
        echo '<div class="' . esc_attr( $classes ) . '"' . (( isset( $field['depends'] ) ? ' data-depends="' . esc_attr( (string) $field['depends'] ) . '"' : '' )) . '>';
        echo '<div class="fd-field-text">';
        echo '<label class="fd-field-label" for="' . esc_attr( $id ) . '">' . esc_html( (string) $field['label'] ) . wp_kses_post( $badge ) . '</label>';
        if ( !empty( $field['help'] ) ) {
            echo '<p class="fd-field-help">' . esc_html( (string) $field['help'] ) . '</p>';
        }
        echo '</div>';
        $wrapper = [
            'div'      => [
                'class' => true,
            ],
            'fieldset' => [
                'class'    => true,
                'disabled' => true,
            ],
        ];
        echo wp_kses( $open, $wrapper );
        $this->renderControl(
            $field,
            $value,
            $id,
            $name
        );
        echo wp_kses( $close, $wrapper );
        echo '</div>';
    }

    /**
     * @param array<string, mixed> $field
     */
    private function renderControl(
        array $field,
        mixed $value,
        string $id,
        string $name
    ) : void {
        switch ( (string) $field['type'] ) {
            case 'toggle':
                printf( '<input type="hidden" name="%s" value="0">', esc_attr( $name ) );
                printf(
                    '<input type="checkbox" class="fd-switch" role="switch" id="%s" name="%s" value="1" data-path="%s" %s>',
                    esc_attr( $id ),
                    esc_attr( $name ),
                    esc_attr( (string) $field['path'] ),
                    checked( (bool) $value, true, false )
                );
                break;
            case 'color':
                printf(
                    '<input type="color" class="fd-color" id="%s" name="%s" value="%s">',
                    esc_attr( $id ),
                    esc_attr( $name ),
                    esc_attr( (string) $value )
                );
                printf(
                    '<input type="text" class="fd-color-text" pattern="#[0-9a-fA-F]{6}" value="%s" data-color-for="%s" aria-label="%s">',
                    esc_attr( (string) $value ),
                    esc_attr( $id ),
                    esc_attr( (string) $field['label'] )
                );
                break;
            case 'textarea':
                printf(
                    '<textarea id="%s" name="%s" rows="4" class="large-text">%s</textarea>',
                    esc_attr( $id ),
                    esc_attr( $name ),
                    esc_textarea( (string) $value )
                );
                break;
            case 'range':
                printf(
                    '<input type="range" class="fd-range" id="%1$s" name="%2$s" value="%3$s" min="%4$s" max="%5$s" step="%6$s" data-unit="%7$s" data-live-var="%8$s"><output class="fd-range-value" for="%1$s" data-unit="%7$s">%3$s%7$s</output>',
                    esc_attr( $id ),
                    esc_attr( $name ),
                    esc_attr( (string) (int) $value ),
                    esc_attr( (string) (int) ($field['min'] ?? 0) ),
                    esc_attr( (string) (int) ($field['max'] ?? 100) ),
                    esc_attr( (string) (int) ($field['step'] ?? 1) ),
                    esc_attr( (string) ($field['unit'] ?? '') ),
                    esc_attr( (string) ($field['live_var'] ?? '') )
                );
                break;
            case 'select':
                printf( '<select id="%s" name="%s">', esc_attr( $id ), esc_attr( $name ) );
                foreach ( (array) $field['options'] as $optionValue => $optionLabel ) {
                    printf(
                        '<option value="%s" %s>%s</option>',
                        esc_attr( (string) $optionValue ),
                        selected( (string) $value, (string) $optionValue, false ),
                        esc_html( (string) $optionLabel )
                    );
                }
                echo '</select>';
                break;
            case 'image':
                $imageId = ( is_numeric( $value ) ? (int) $value : 0 );
                $url = ( $imageId > 0 ? wp_get_attachment_image_url( $imageId, 'medium' ) : false );
                echo '<div class="fd-image">';
                printf(
                    '<input type="hidden" id="%s" name="%s" value="%s">',
                    esc_attr( $id ),
                    esc_attr( $name ),
                    esc_attr( ( $imageId > 0 ? (string) $imageId : '' ) )
                );
                printf(
                    '<span class="fd-image-preview%s"%s>%s</span>',
                    ( !empty( $field['dark_preview'] ) ? ' is-dark' : '' ),
                    ( $url ? '' : ' hidden' ),
                    ( $url ? '<img src="' . esc_url( $url ) . '" alt="">' : '' )
                );
                printf(
                    '<button type="button" class="button" data-fd-image-choose data-title="%s" data-button="%s">%s</button>',
                    esc_attr( (string) $field['label'] ),
                    esc_attr__( 'Use this image', 'featherdash' ),
                    esc_html__( 'Choose image', 'featherdash' )
                );
                printf( '<button type="button" class="button-link button-link-delete" data-fd-image-remove%s>%s</button>', ( $url ? '' : ' hidden' ), esc_html__( 'Remove', 'featherdash' ) );
                echo '</div>';
                break;
            case 'keys':
                // Checklist of plugin items (toolbar nodes, dashboard widgets):
                // the field's 'source' lists known items of active plugins and
                // items recorded at runtime; anything already ticked is added.
                $values = ( is_array( $value ) ? array_map( 'strval', $value ) : [] );
                // '*' (a default) means every item stays: tick them all and post
                // '*' back, so saving another setting keeps it. settings.js
                // drops the marker as soon as a box in this list is unticked.
                $all = in_array( '*', $values, true );
                $values = array_values( array_diff( $values, ['*'] ) );
                $options = ( isset( $field['source'] ) && is_callable( $field['source'] ) ? (array) call_user_func( $field['source'] ) : [] );
                foreach ( $values as $kept ) {
                    $options[$kept] ??= [
                        'label'  => $kept,
                        'plugin' => '',
                        'active' => true,
                    ];
                }
                // 'columns' => 1 for lists of long entries (people, notices).
                $single = ( (int) ($field['columns'] ?? 2) === 1 ? ' fd-checklist--single' : '' );
                echo '<fieldset class="' . esc_attr( 'fd-checklist fd-checklist--nodes' . $single ) . '">';
                printf( '<input type="hidden" name="%s[]" value="">', esc_attr( $name ) );
                if ( $all ) {
                    printf( '<input type="hidden" name="%s[]" value="*" data-fd-keep-all>', esc_attr( $name ) );
                }
                foreach ( $options as $optionValue => $option ) {
                    printf(
                        '<label class="fd-check%s"%s><input type="checkbox" name="%s[]" value="%s" %s> <span class="fd-check-text"><span>%s%s</span><code>%s</code></span></label>',
                        ( $option['active'] ? '' : ' is-inactive' ),
                        ( $option['active'] ? '' : ' title="' . esc_attr__( 'This plugin is not active.', 'featherdash' ) . '"' ),
                        esc_attr( $name ),
                        esc_attr( (string) $optionValue ),
                        checked( $all || in_array( (string) $optionValue, $values, true ), true, false ),
                        ( $option['plugin'] !== '' ? '<strong>' . esc_html( $option['plugin'] ) . '</strong> · ' : '' ),
                        esc_html( $option['label'] ),
                        esc_html( (string) $optionValue )
                    );
                }
                echo '</fieldset>';
                break;
            case 'checklist':
                $values = ( is_array( $value ) ? array_map( 'strval', $value ) : [] );
                echo '<fieldset class="fd-checklist">';
                printf( '<input type="hidden" name="%s[]" value="">', esc_attr( $name ) );
                foreach ( (array) $field['options'] as $optionValue => $optionLabel ) {
                    printf(
                        '<label class="fd-check"><input type="checkbox" name="%s[]" value="%s" %s> %s</label>',
                        esc_attr( $name ),
                        esc_attr( (string) $optionValue ),
                        checked( in_array( (string) $optionValue, $values, true ), true, false ),
                        esc_html( (string) $optionLabel )
                    );
                }
                echo '</fieldset>';
                break;
            default:
                printf(
                    '<input type="text" class="regular-text" id="%s" name="%s" value="%s">',
                    esc_attr( $id ),
                    esc_attr( $name ),
                    esc_attr( (string) $value )
                );
                break;
        }
    }

    private function renderTools( About $about ) : void {
        $export = $this->settings->stored();
        $json = (string) wp_json_encode( $export, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
        $action = admin_url( 'admin-post.php' );
        ?>
        <section class="fd-panel" id="fd-panel-tools" role="tabpanel" data-tab="tools" data-standalone>
            <?php 
        $about->tabLink( 'tools' );
        ?>
            <?php 
        ?>
            <div class="fd-card fd-tools">
                <h2 class="fd-card-title"><?php 
        esc_html_e( 'Tools', 'featherdash' );
        ?></h2>
                <p class="fd-card-desc"><?php 
        esc_html_e( 'Export, import or reset all FeatherDash settings.', 'featherdash' );
        ?></p>
                <div class="fd-field fd-field--textarea">
                    <div class="fd-field-text">
                        <label class="fd-field-label" for="fd-export"><?php 
        esc_html_e( 'Export all FeatherDash settings', 'featherdash' );
        ?></label>
                        <p class="fd-field-help"><?php 
        esc_html_e( 'Copy this JSON to back up all FeatherDash settings.', 'featherdash' );
        ?></p>
                    </div>
                    <div class="fd-field-control">
                        <textarea id="fd-export" class="large-text code" rows="10" readonly><?php 
        echo esc_textarea( $json );
        ?></textarea>
                        <?php 
        $filename = 'featherdash-' . sanitize_title( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ) . '-' . wp_date( 'Y-m-d' ) . '.json';
        ?>
                        <div class="fd-tools-download">
                            <button type="button" class="button fd-download" data-target="fd-export" data-filename="<?php 
        echo esc_attr( $filename );
        ?>">
                                <span class="dashicons dashicons-download" aria-hidden="true"></span><?php 
        esc_html_e( 'Export to JSON', 'featherdash' );
        ?>
                            </button>
                        </div>
                        <div class="fd-tools-actions">
                            <button type="button" class="button fd-copy" data-target="fd-export" data-done="<?php 
        esc_attr_e( 'Copied', 'featherdash' );
        ?>">
                                <span class="dashicons dashicons-clipboard" aria-hidden="true"></span><?php 
        esc_html_e( 'Copy', 'featherdash' );
        ?>
                            </button>
                        </div>
                    </div>
                </div>
                <form method="post" action="<?php 
        echo esc_url( $action );
        ?>" class="fd-tools-form">
                    <?php 
        wp_nonce_field( 'featherdash_import' );
        ?>
                    <input type="hidden" name="action" value="featherdash_import">
                    <div class="fd-field fd-field--textarea">
                        <div class="fd-field-text">
                            <label class="fd-field-label" for="fd-import"><?php 
        esc_html_e( 'Import all FeatherDash settings', 'featherdash' );
        ?></label>
                            <p class="fd-field-help"><?php 
        esc_html_e( 'Paste exported JSON and replace all current FeatherDash settings.', 'featherdash' );
        ?></p>
                        </div>
                        <div class="fd-field-control">
                            <textarea id="fd-import" name="featherdash_import" class="large-text code" rows="10"></textarea>
                            <div class="fd-tools-actions">
                                <button type="button" class="button fd-paste" data-target="fd-import" data-done="<?php 
        esc_attr_e( 'Pasted', 'featherdash' );
        ?>" data-denied="<?php 
        esc_attr_e( 'Clipboard not available: paste with Ctrl+V', 'featherdash' );
        ?>">
                                    <span class="dashicons dashicons-editor-paste-text" aria-hidden="true"></span><?php 
        esc_html_e( 'Paste', 'featherdash' );
        ?>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="fd-tools-footer">
                        <div class="fd-tools-footer-start">
                            <button type="submit" class="button"><?php 
        esc_html_e( 'Import settings', 'featherdash' );
        ?></button>
                            <input type="file" id="fd-import-file" accept=".json,application/json" hidden>
                            <button type="button" class="button fd-upload" data-target="fd-import" data-file="fd-import-file" data-done="<?php 
        esc_attr_e( 'Loaded — now click Import settings', 'featherdash' );
        ?>" data-invalid="<?php 
        esc_attr_e( 'That file isn\'t valid JSON', 'featherdash' );
        ?>">
                                <span class="dashicons dashicons-upload" aria-hidden="true"></span><?php 
        esc_html_e( 'Import from JSON', 'featherdash' );
        ?>
                            </button>
                        </div>
                        <?php 
        // Submits the reset form below (forms can't be nested).
        ?>
                        <button type="submit" form="fd-reset-form" class="button-link button-link-delete fd-reset-link" data-confirm="<?php 
        esc_attr_e( 'Reset all FeatherDash settings, including the menu layout, to their defaults? This cannot be undone.', 'featherdash' );
        ?>"><?php 
        esc_html_e( 'Reset all settings to defaults', 'featherdash' );
        ?></button>
                    </div>
                </form>
                <form method="post" action="<?php 
        echo esc_url( $action );
        ?>" id="fd-reset-form" hidden>
                    <?php 
        wp_nonce_field( 'featherdash_reset' );
        ?>
                    <input type="hidden" name="action" value="featherdash_reset">
                </form>
            </div>
        </section>
        <?php 
    }

    /**
     * One "FeatherDash Pro" card on the About tab, without Pro.
     */
    private function renderProCard() : void {
        $features = [
            __( 'Modern and Light themes with a per-user theme switch', 'featherdash' ),
            __( 'Drag-and-drop admin menu builder', 'featherdash' ),
            __( 'Hide toolbar items and dashboard widgets added by plugins', 'featherdash' ),
            __( 'Post type columns: order, hide, sort, ACF fields', 'featherdash' ),
            __( 'GA4 dashboard widget and live visitors', 'featherdash' ),
            __( 'Admin notice manager, white label and settings lock', 'featherdash' ),
            __( 'Open Graph & X cards, login and maintenance background images', 'featherdash' )
        ];
        ?>
        <div class="fd-card fd-pro-card">
            <h2 class="fd-card-title"><?php 
        esc_html_e( 'FeatherDash Pro', 'featherdash' );
        ?></h2>
            <p class="fd-card-desc"><?php 
        esc_html_e( 'Everything agencies need to hand over a tidy, branded admin.', 'featherdash' );
        ?></p>
            <ul class="fd-pro-list">
                <?php 
        foreach ( $features as $feature ) {
            ?>
                    <li><?php 
            echo esc_html( $feature );
            ?></li>
                <?php 
        }
        ?>
            </ul>
            <p class="fd-pro-actions">
                <a class="button button-primary" href="<?php 
        echo esc_url( Pro::upgradeUrl() );
        ?>"><?php 
        esc_html_e( 'Get FeatherDash Pro', 'featherdash' );
        ?></a>
                <a class="button" href="<?php 
        echo esc_url( Licensing::PRO_URL );
        ?>" target="_blank" rel="noopener"><?php 
        esc_html_e( 'See all features', 'featherdash' );
        ?></a>
            </p>
        </div>
        <?php 
    }

    /**
     * After 14 days, once per user: "Enjoying FeatherDash? A review helps a lot".
     * Never on the agency's own sites.
     */
    private function renderReviewLink() : void {
        $since = (int) get_option( self::INSTALLED_OPTION, 0 );
        if ( Licensing::agency() || $since === 0 || time() - $since < 14 * DAY_IN_SECONDS || get_user_meta( get_current_user_id(), self::REVIEW_META, true ) ) {
            return;
        }
        $url = static fn( string $answer ): string => wp_nonce_url( add_query_arg( [
            'action' => 'featherdash_review',
            'answer' => $answer,
        ], admin_url( 'admin-post.php' ) ), 'featherdash_review' );
        printf(
            '<p class="fd-review">%s <a href="%s" target="_blank" rel="noopener">%s</a> <a class="fd-review-dismiss" href="%s" aria-label="%s">&times;</a></p>',
            esc_html__( 'Enjoying FeatherDash?', 'featherdash' ),
            esc_url( $url( 'review' ) ),
            esc_html__( 'A review helps a lot', 'featherdash' ),
            esc_url( $url( 'dismiss' ) ),
            esc_attr__( 'Don\'t ask again', 'featherdash' )
        );
    }

    /**
     * Records the answer to the review request, then goes to WordPress.org
     * or back to the settings page.
     */
    public function review() : void {
        check_admin_referer( 'featherdash_review' );
        if ( !current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Sorry, you are not allowed to do that.', 'featherdash' ), 403 );
        }
        update_user_meta( get_current_user_id(), self::REVIEW_META, time() );
        if ( sanitize_key( wp_unslash( (string) ($_GET['answer'] ?? '') ) ) === 'review' ) {
            add_filter( 'allowed_redirect_hosts', static fn( array $hosts ): array => [...$hosts, 'wordpress.org'] );
            wp_safe_redirect( self::REVIEW_URL );
            exit;
        }
        wp_safe_redirect( admin_url( 'options-general.php?page=featherdash' ) );
        exit;
    }

    public function importSettings() : void {
        if ( !current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You are not allowed to do this.', 'featherdash' ) );
        }
        check_admin_referer( 'featherdash_import' );
        // Raw JSON: decoded below, and every value goes through Settings::sanitize().
        // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- JSON, sanitised value by value after decoding.
        $raw = ( isset( $_POST['featherdash_import'] ) && is_string( $_POST['featherdash_import'] ) ? wp_unslash( $_POST['featherdash_import'] ) : '' );
        $decoded = json_decode( $raw, true );
        if ( !is_array( $decoded ) ) {
            wp_safe_redirect( add_query_arg( [
                'page'     => 'featherdash',
                'fd-error' => 'import',
            ], admin_url( 'options-general.php' ) ) . '#tools' );
            exit;
        }
        $menu = $decoded['menu'] ?? null;
        unset($decoded['menu']);
        update_option( Settings::OPTION, Settings::sanitize( $decoded ) );
        /**
         * Fires after settings were imported on the Tools tab.
         *
         * @param array<string, mixed> $settings The saved settings.
         */
        do_action( 'featherdash/settings_imported', Settings::instance()->stored() );
        $this->redirectSaved( __( 'Settings imported.', 'featherdash' ) );
    }

    public function resetSettings() : void {
        if ( !current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You are not allowed to do this.', 'featherdash' ) );
        }
        check_admin_referer( 'featherdash_reset' );
        delete_option( Settings::OPTION );
        /**
         * Fires after all settings and the menu layout were reset to defaults.
         */
        do_action( 'featherdash/settings_reset' );
        $this->redirectSaved( __( 'Settings reset to defaults.', 'featherdash' ) );
    }

    private function redirectSaved( string $message ) : never {
        add_settings_error(
            'featherdash',
            'settings_updated',
            $message,
            'success'
        );
        set_transient( 'settings_errors', get_settings_errors(), 30 );
        wp_safe_redirect( add_query_arg( [
            'page'             => 'featherdash',
            'settings-updated' => 'true',
        ], admin_url( 'options-general.php' ) ) . '#tools' );
        exit;
    }

    private function fieldName( string $path ) : string {
        return 'featherdash_settings[' . implode( '][', explode( '.', $path ) ) . ']';
    }

    private function fieldId( string $path ) : string {
        return 'fd-' . str_replace( '.', '-', $path );
    }

    private function version( string $relative ) : string {
        $mtime = filemtime( FEATHERDASH_DIR . $relative );
        return ( $mtime === false ? FEATHERDASH_VERSION : (string) $mtime );
    }

}
