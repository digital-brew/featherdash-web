<?php

declare (strict_types = 1);
namespace DigitalBrew\Featherdash;

use DigitalBrew\Featherdash\Modules\Admin\Bar;
use DigitalBrew\Featherdash\Modules\Admin\Cleanup;
use DigitalBrew\Featherdash\Modules\Admin\Dashboard;
use DigitalBrew\Featherdash\Modules\Admin\Footer;
use DigitalBrew\Featherdash\Modules\Admin\Navigation;
use DigitalBrew\Featherdash\Modules\Admin\Tables;
use DigitalBrew\Featherdash\Modules\Admin\Theme;
use DigitalBrew\Featherdash\Modules\Admin\Welcome;
use DigitalBrew\Featherdash\Modules\Content\Comments;
use DigitalBrew\Featherdash\Modules\Content\LastLogin;
use DigitalBrew\Featherdash\Modules\Content\Posts;
use DigitalBrew\Featherdash\Modules\Front\Favicon;
use DigitalBrew\Featherdash\Modules\Front\Head;
use DigitalBrew\Featherdash\Modules\Front\JQuery;
use DigitalBrew\Featherdash\Modules\Front\Tracking;
use DigitalBrew\Featherdash\Modules\Login;
use DigitalBrew\Featherdash\Modules\Maintenance;
use DigitalBrew\Featherdash\Modules\Security;
use DigitalBrew\Featherdash\Licensing\Pro;
use DigitalBrew\Featherdash\Settings\Settings;
use DigitalBrew\Featherdash\Settings\SettingsPage;
final class Plugin {
    public static function boot() : void {
        $settings = Settings::instance();
        if ( is_admin() ) {
            ( new SettingsPage($settings) )->register();
            // Also covers sites activated before uninstall.php was replaced.
            add_action( 'admin_init', [Uninstall::class, 'register'] );
        }
        /**
         * Filters the module classes FeatherDash boots. Remove one to switch a
         * feature off in code, or add your own: a class with a public
         * `register(Settings $settings)` method that adds hooks.
         *
         * @param array<int, class-string> $modules
         */
        $modules = self::modules();
        $modules = (array) apply_filters( 'featherdash/modules', $modules, $settings );
        foreach ( $modules as $class ) {
            if ( is_string( $class ) && class_exists( $class ) && method_exists( $class, 'register' ) ) {
                ( new $class() )->register( $settings );
            }
        }
        /**
         * Fires after every module registered its hooks.
         *
         * @param Settings $settings
         */
        do_action( 'featherdash/loaded', $settings );
    }

    /**
     * @return array<int, class-string>
     */
    private static function modules() : array {
        return [
            Theme::class,
            Navigation::class,
            Bar::class,
            Dashboard::class,
            Footer::class,
            Tables::class,
            Welcome::class,
            Cleanup::class,
            Comments::class,
            Posts::class,
            LastLogin::class,
            Head::class,
            JQuery::class,
            Tracking::class,
            Favicon::class,
            Security::class,
            Login::class,
            Maintenance::class
        ];
    }

}
