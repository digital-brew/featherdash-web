<?php

declare(strict_types=1);

namespace DigitalBrew\Featherdash;

use DigitalBrew\Featherdash\Licensing\Licensing;

/**
 * Removes FeatherDash's data when the plugin is deleted. Freemius calls it
 * (`after_uninstall`) when licensing is on; in agency mode WordPress does,
 * through the hook registered on activation. A plugin-level uninstall.php
 * would stop Freemius' own uninstall hook from running.
 */
final class Uninstall
{
    public static function register(): void
    {
        if (Licensing::agency()) {
            register_uninstall_hook(FEATHERDASH_FILE, [self::class, 'run']);
        }
    }

    public static function run(): void
    {
        // The free and Pro copies share their data: keep it while the other
        // copy is still installed (e.g. the free one deleted after upgrading).
        if (self::otherCopyInstalled()) {
            return;
        }

        foreach ([
            'featherdash_settings',
            'featherdash_menu',
            'featherdash_toolbar_items',
            'featherdash_dashboard_widgets',
            'featherdash_columns_seen',
            'featherdash_columns_sortable',
            'featherdash_notices_seen',
            'featherdash_installed',
        ] as $option) {
            delete_option($option);
        }

        foreach (['featherdash_sidebar', 'featherdash_snoozed_notices', 'featherdash_review_asked'] as $key) {
            delete_metadata('user', 0, $key, '', true);
        }

        foreach (['_featherdash_og_title', '_featherdash_og_description', '_featherdash_og_image'] as $key) {
            delete_metadata('post', 0, $key, '', true);
        }
    }

    private static function otherCopyInstalled(): bool
    {
        if (! function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $self = plugin_basename(FEATHERDASH_FILE);

        foreach (array_keys(get_plugins()) as $file) {
            if ($file !== $self && preg_match('#^featherdash(-pro)?(-[\w.-]+)?/featherdash\.php$#', (string) $file) === 1) {
                return true;
            }
        }

        return false;
    }
}
