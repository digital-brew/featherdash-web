<?php

declare (strict_types = 1);
namespace DigitalBrew\Featherdash\Licensing;

use DigitalBrew\Featherdash\Uninstall;
/**
 * Freemius bootstrap.
 *
 * Freemius handles licences, updates and opt-in usage data for the sold
 * build, and its deployment produces the free (WordPress.org) zip without the
 * `__premium_only` code. Until the product is set up (ID and key below are
 * empty), or on the agency's own sites (`FEATHERDASH_AGENCY`), Freemius isn't
 * loaded and every feature is on.
 */
final class Licensing {
    /** Freemius product ID (Developer Dashboard → Settings). */
    public const ID = '42160';

    /** Freemius public key (pk_…). */
    public const PUBLIC_KEY = 'pk_76113026c5e682104fb14d697f06f';

    /** Landing page with the Pro features. */
    public const PRO_URL = 'https://featherdash.io/pro/';

    private static ?object $fs = null;

    /**
     * The Freemius instance, or a stand-in while Freemius isn't used.
     */
    public static function fs() : object {
        if ( self::$fs !== null ) {
            return self::$fs;
        }
        // The agency's own sites, or no Freemius product: a stand-in.
        $standIn = __NAMESPACE__ . '\\Unlicensed';
        if ( class_exists( $standIn ) && (self::agency() || self::ID === '' || self::PUBLIC_KEY === '') ) {
            self::$fs = new $standIn();
            return self::$fs;
        }
        require_once FEATHERDASH_DIR . 'vendor/freemius/start.php';
        self::$fs = fs_dynamic_init( [
            'id'               => self::ID,
            'slug'             => 'featherdash',
            'premium_slug'     => 'featherdash-pro',
            'type'             => 'plugin',
            'public_key'       => self::PUBLIC_KEY,
            'is_premium'       => false,
            'premium_suffix'   => 'Pro',
            'has_addons'       => false,
            'has_paid_plans'   => true,
            'is_org_compliant' => true,
            'menu'             => [
                'slug'       => 'featherdash',
                'first-path' => 'options-general.php?page=featherdash',
                'parent'     => [
                    'slug' => 'options-general.php',
                ],
                'contact'    => true,
                'support'    => false,
            ],
            'is_live'          => true,
        ] );
        // Freemius runs WordPress' uninstall for us and reports it.
        self::$fs->add_action( 'after_uninstall', [Uninstall::class, 'run'] );
        // Our icon on the pricing and opt-in screens, instead of the SDK's
        // default (it has no WordPress.org icon to fetch). The path goes
        // through WP_PLUGIN_DIR because Freemius turns it into a URL by
        // prefix, which fails for a symlinked plugin's real path.
        self::$fs->add_filter( 'plugin_icon', static fn(): string => WP_PLUGIN_DIR . '/' . dirname( plugin_basename( FEATHERDASH_FILE ) ) . '/assets/images/icon-256x256.png' );
        do_action( 'featherdash_fs_loaded' );
        return self::$fs;
    }

    /**
     * Agency mode: the DigitalBrew client sites need no licence. On when
     * FEATHERDASH_AGENCY is true, or (without the constant) when the
     * `.featherdash-agency` marker is present — it is in the git repository the
     * sites install from with Composer, and bin/release-zip.sh leaves it out
     * of the Freemius upload. Also on while the Freemius product isn't set up.
     */
    public static function agency() : bool {
        if ( defined( 'FEATHERDASH_AGENCY' ) ) {
            return (bool) FEATHERDASH_AGENCY;
        }
        return self::ID === '' || self::PUBLIC_KEY === '' || file_exists( FEATHERDASH_DIR . '.featherdash-agency' );
    }

}
