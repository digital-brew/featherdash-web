<?php

declare (strict_types = 1);
namespace DigitalBrew\Featherdash\Licensing;

/**
 * Whether Pro features are available.
 */
final class Pro {
    private static ?bool $active = null;

    public static function active() : bool {
        if ( self::$active !== null ) {
            return self::$active;
        }
        $active = false;
        self::$active = $active;
        return $active;
    }

    /**
     * Previewing the free plugin on a development site (FEATHERDASH_FREE_PREVIEW):
     * Pro code that the free build doesn't have is skipped as well.
     */
    public static function freePreview() : bool {
        return defined( 'FEATHERDASH_FREE_PREVIEW' ) && FEATHERDASH_FREE_PREVIEW;
    }

    public static function upgradeUrl() : string {
        $url = Licensing::PRO_URL;
        if ( !Licensing::agency() ) {
            $url = (string) featherdash_fs()->get_upgrade_url();
        }
        return $url;
    }

}
