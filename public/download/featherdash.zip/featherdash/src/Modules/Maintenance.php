<?php

declare (strict_types = 1);
namespace DigitalBrew\Featherdash\Modules;

use DigitalBrew\Featherdash\Licensing\Pro;
use DigitalBrew\Featherdash\Settings\Settings;
use WP_Admin_Bar;
/**
 * Maintenance mode: front-end requests from visitors who can't edit content
 * get a 503 holding page. The admin, wp-login.php, REST, AJAX and cron never
 * reach template_redirect, so they keep working. Administrators can preview
 * the page at /?fd-maintenance-preview=1 whether or not it is switched on.
 */
final class Maintenance {
    public const PREVIEW_ARG = 'fd-maintenance-preview';

    /** Users with this capability see the site normally. */
    private const BYPASS_CAP = 'edit_posts';

    private Settings $settings;

    public function register( Settings $settings ) : void {
        $this->settings = $settings;
        add_action( 'template_redirect', [$this, 'maybeRender'], 0 );
        if ( $settings->get( 'maintenance.enabled', false ) ) {
            add_action( 'admin_bar_menu', [$this, 'toolbarBadge'], 100 );
            add_action( 'admin_enqueue_scripts', [$this, 'badgeCss'] );
            add_action( 'wp_enqueue_scripts', [$this, 'badgeCss'] );
        }
    }

    /**
     * Footer of the Maintenance settings card.
     */
    public static function renderPreviewLink() : void {
        printf(
            '<a class="button" href="%s" target="_blank" rel="noopener">%s</a><span>%s</span>',
            esc_url( add_query_arg( self::PREVIEW_ARG, '1', home_url( '/' ) ) ),
            esc_html__( 'Preview the maintenance page', 'featherdash' ),
            esc_html__( 'Save your changes first. The preview works while maintenance mode is off.', 'featherdash' )
        );
    }

    public function maybeRender() : void {
        // A read-only preview for administrators, so no nonce.
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only preview for administrators.
        $preview = isset( $_GET[self::PREVIEW_ARG] ) && current_user_can( 'manage_options' );
        if ( !$preview ) {
            if ( !$this->settings->get( 'maintenance.enabled', false ) || self::canBypass() ) {
                return;
            }
            /**
             * Filters the Retry-After header of the maintenance page, in seconds.
             *
             * @param int $seconds
             */
            $retry = (int) apply_filters( 'featherdash/maintenance/retry_after', 3600 );
            status_header( 503 );
            if ( $retry > 0 ) {
                header( 'Retry-After: ' . $retry );
            }
        }
        nocache_headers();
        header( 'Content-Type: text/html; charset=' . get_bloginfo( 'charset' ) );
        $this->render();
        exit;
    }

    /**
     * Whether the current visitor sees the site instead of the maintenance page.
     */
    public static function canBypass() : bool {
        /**
         * Filters whether the current visitor skips the maintenance page.
         * By default users who can edit posts do.
         *
         * @param bool $bypass
         */
        return (bool) apply_filters( 'featherdash/maintenance/bypass', current_user_can( self::BYPASS_CAP ) );
    }

    public function toolbarBadge( WP_Admin_Bar $bar ) : void {
        if ( !self::canBypass() || !is_user_logged_in() ) {
            return;
        }
        $bar->add_node( [
            'id'     => 'fd-maintenance',
            'parent' => 'top-secondary',
            'title'  => esc_html__( 'Maintenance mode', 'featherdash' ),
            'href'   => ( current_user_can( 'manage_options' ) ? admin_url( 'options-general.php?page=featherdash#maintenance' ) : false ),
            'meta'   => [
                'title' => __( 'Visitors see the maintenance page. You see the site because you are logged in.', 'featherdash' ),
            ],
        ] );
    }

    public function badgeCss() : void {
        if ( !is_admin_bar_showing() || !self::canBypass() ) {
            return;
        }
        // Desktop only: on phones the toolbar keeps just core's essential icons.
        wp_register_style(
            'featherdash-maintenance-badge',
            false,
            ['admin-bar'],
            FEATHERDASH_VERSION
        );
        wp_enqueue_style( 'featherdash-maintenance-badge' );
        wp_add_inline_style( 'featherdash-maintenance-badge', '@media screen and (min-width:783px){' . '#wpadminbar #wp-admin-bar-fd-maintenance{display:flex;align-items:center;height:var(--fd-bar-h,var(--wp-admin--admin-bar--height,32px))}' . '#wpadminbar #wp-admin-bar-fd-maintenance>.ab-item,#wpadminbar #wp-admin-bar-fd-maintenance:hover>.ab-item,#wpadminbar #wp-admin-bar-fd-maintenance>.ab-item:focus' . '{height:auto;padding:0 8px;line-height:22px;border-radius:4px;background:#d63638;color:#fff}' . '}' );
    }

    private function render() : void {
        $title = (string) $this->settings->get( 'maintenance.title', '' );
        $subtitle = (string) $this->settings->get( 'maintenance.subtitle', '' );
        $body = trim( (string) $this->settings->get( 'maintenance.body', '' ) );
        $background = (string) $this->settings->get( 'maintenance.background', '#1e1e1e' );
        $text = (string) $this->settings->get( 'maintenance.text_color', '#ffffff' );
        $image = false;
        $view = [
            'title'      => ( $title !== '' ? $title : (string) get_bloginfo( 'name' ) ),
            'subtitle'   => $subtitle,
            'body'       => ( $body !== '' ? wpautop( wp_kses_post( $body ) ) : '' ),
            'background' => $background,
            'text'       => $text,
            'image'      => ( is_string( $image ) ? $image : '' ),
            'site'       => (string) get_bloginfo( 'name' ),
            'lang'       => get_language_attributes(),
            'charset'    => (string) get_bloginfo( 'charset' ),
            'icon'       => get_site_icon_url( 64 ),
        ];
        /**
         * Filters the maintenance page's data. `body` is HTML; `background` and
         * `text` must stay hex colours and `image` a URL.
         *
         * @param array<string, mixed> $view
         */
        $view = array_merge( $view, (array) apply_filters( 'featherdash/maintenance/view', $view ) );
        // The template prints these inside <style>, so re-check filtered values.
        $view['background'] = ( sanitize_hex_color( (string) $view['background'] ) ?: '#1e1e1e' );
        $view['text'] = ( sanitize_hex_color( (string) $view['text'] ) ?: '#ffffff' );
        $view['image'] = esc_url_raw( (string) $view['image'] );
        // With an image, the background colour becomes a tint over it so the
        // text stays readable. Colours are sanitised hex values and
        // esc_url_raw() strips quotes, so nothing can break out of url("…").
        $background = ( $view['image'] !== '' ? sprintf( 'linear-gradient(color-mix(in srgb, %1$s 55%%, transparent), color-mix(in srgb, %1$s 55%%, transparent)), url("%2$s") center / cover no-repeat, %1$s', $view['background'], $view['image'] ) : $view['background'] );
        wp_register_style(
            'featherdash-maintenance',
            FEATHERDASH_URL . 'dist/maintenance.css',
            [],
            ( file_exists( FEATHERDASH_DIR . 'dist/maintenance.css' ) ? (string) filemtime( FEATHERDASH_DIR . 'dist/maintenance.css' ) : FEATHERDASH_VERSION )
        );
        wp_add_inline_style( 'featherdash-maintenance', 'body.fd-maintenance{--fd-maintenance-bg:' . $background . ';--fd-maintenance-text:' . $view['text'] . '}' );
        /**
         * Filters the maintenance page template file.
         *
         * @param string $template Absolute path.
         */
        $template = (string) apply_filters( 'featherdash/maintenance/template', FEATHERDASH_DIR . 'templates/maintenance.php' );
        include ( is_readable( $template ) ? $template : FEATHERDASH_DIR . 'templates/maintenance.php' );
    }

}
