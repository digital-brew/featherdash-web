<?php

declare (strict_types = 1);
namespace DigitalBrew\Featherdash\Modules\Admin;

use DigitalBrew\Featherdash\Licensing\Pro;
use DigitalBrew\Featherdash\Settings\Schema;
use DigitalBrew\Featherdash\Settings\Settings;
/**
 * The welcome / support dashboard widget an agency writes once for its
 * clients: logo, message, a main button (e.g. "Read our knowledge base") and links.
 */
final class Welcome {
    public const WIDGET_ID = 'featherdash_welcome';

    private Settings $settings;

    public function register( Settings $settings ) : void {
        $this->settings = $settings;
        if ( $settings->get( 'welcome.enabled', false ) ) {
            add_action( 'wp_dashboard_setup', [$this, 'add'] );
        }
    }

    public function add() : void {
        // wp_dashboard_setup runs before the admin header enqueues styles.
        wp_register_style(
            'featherdash-welcome',
            false,
            [],
            FEATHERDASH_VERSION
        );
        wp_enqueue_style( 'featherdash-welcome' );
        wp_add_inline_style( 'featherdash-welcome', '#featherdash_welcome .fd-welcome-logo{display:block;max-width:180px;max-height:64px;width:auto;height:auto;margin:4px 0 12px}' . '#featherdash_welcome .fd-welcome-body>:first-child{margin-top:0}' . '#featherdash_welcome .fd-welcome-button{margin:4px 0 8px}' . '#featherdash_welcome .fd-welcome-links{margin:12px 0 0;padding:12px 0 0;border-top:1px solid #f0f0f1;list-style:none}' . '#featherdash_welcome .fd-welcome-links li{margin:0 0 6px}' );
        $title = trim( (string) $this->settings->get( 'welcome.title', '' ) );
        wp_add_dashboard_widget(
            self::WIDGET_ID,
            esc_html( ( $title !== '' ? $title : __( 'Welcome', 'featherdash' ) ) ),
            [$this, 'render'],
            null,
            null,
            'normal',
            'high'
        );
    }

    public function render() : void {
        $logo = wp_get_attachment_image(
            (int) $this->settings->get( 'welcome.logo', 0 ),
            'medium',
            false,
            [
                'class' => 'fd-welcome-logo',
                'alt'   => '',
            ]
        );
        $body = trim( (string) $this->settings->get( 'welcome.body', '' ) );
        $label = trim( (string) $this->settings->get( 'welcome.button_label', '' ) );
        $url = (string) $this->settings->get( 'welcome.button_url', '' );
        $links = Schema::links( (string) $this->settings->get( 'welcome.links', '' ) );
        echo '<div class="fd-welcome">';
        if ( $logo !== '' ) {
            echo wp_kses_post( $logo );
        }
        if ( $body !== '' ) {
            echo '<div class="fd-welcome-body">' . wp_kses_post( wpautop( $body ) ) . '</div>';
        }
        if ( $label !== '' && $url !== '' ) {
            printf(
                '<p class="fd-welcome-button"><a class="button button-primary" href="%s"%s>%s</a></p>',
                esc_url( $url, [
                    'http',
                    'https',
                    'mailto',
                    'tel'
                ] ),
                ( str_starts_with( $url, 'http' ) ? ' target="_blank" rel="noopener"' : '' ),
                esc_html( $label )
            );
        }
        if ( $links !== [] ) {
            echo '<ul class="fd-welcome-links">';
            foreach ( $links as $link ) {
                printf(
                    '<li><a href="%s"%s>%s</a></li>',
                    esc_url( $link['url'], [
                        'http',
                        'https',
                        'mailto',
                        'tel'
                    ] ),
                    ( str_starts_with( $link['url'], 'http' ) ? ' target="_blank" rel="noopener"' : '' ),
                    esc_html( $link['label'] )
                );
            }
            echo '</ul>';
        }
        echo '</div>';
    }

}
