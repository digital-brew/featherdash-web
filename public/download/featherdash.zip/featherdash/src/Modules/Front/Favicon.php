<?php

declare(strict_types=1);

namespace DigitalBrew\Featherdash\Modules\Front;

use DigitalBrew\Featherdash\Settings\Settings;

/**
 * Favicon (Site identity → Favicon): edits WordPress' own Site Icon
 * (`site_icon`, the Customizer's Site Identity → Site Icon), so WordPress
 * prints every icon size itself on the site, the admin and the login screen.
 */
final class Favicon
{
    /** Form field name, outside featherdash_settings so it is never stored there. */
    public const FIELD = 'featherdash_site_icon';

    public function register(Settings $settings): void
    {
        add_filter('pre_update_option_' . Settings::OPTION, [$this, 'save']);
    }

    /**
     * The current Site Icon attachment ID, for the settings field.
     */
    public static function current(): int
    {
        return (int) get_option('site_icon', 0);
    }

    /**
     * Saves the Site Icon when the FeatherDash settings form is posted
     * (options.php has checked the nonce by then). Programmatic updates of
     * the settings never touch it, as the field isn't in their data.
     *
     * @param mixed $value
     *
     * @return mixed
     */
    public function save($value)
    {
        if (! isset($_POST[self::FIELD], $_POST['option_page']) || $_POST['option_page'] !== 'featherdash' || ! current_user_can('manage_options')
            || ! wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['_wpnonce'] ?? '')), 'featherdash-options')) {
            return $value;
        }

        $id = absint(wp_unslash($_POST[self::FIELD]));

        if ($id > 0 && wp_attachment_is_image($id)) {
            update_option('site_icon', $id);
        } elseif ($id === 0) {
            delete_option('site_icon');
        }

        return $value;
    }
}
