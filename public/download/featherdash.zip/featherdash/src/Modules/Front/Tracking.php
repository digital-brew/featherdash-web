<?php

declare(strict_types=1);

namespace DigitalBrew\Featherdash\Modules\Front;

use DigitalBrew\Featherdash\Settings\Settings;

/**
 * Front-end tags (Analytics → Tracking): the GA4 tag (gtag.js) with Consent
 * Mode defaults, the Search Console verification meta tag and the Meta Pixel.
 */
final class Tracking
{
    private Settings $settings;

    public function register(Settings $settings): void
    {
        $this->settings = $settings;

        // Early in <head>: Consent Mode defaults must come before any other tag.
        add_action('wp_head', [$this, 'verification'], 1);
        add_action('wp_head', [$this, 'tag'], 2);
        add_action('wp_head', [$this, 'metaPixel'], 3);
    }

    public function verification(): void
    {
        $code = (string) $this->settings->get('analytics.tracking.verification', '');

        if ($code !== '' && (is_front_page() || is_home())) {
            printf('<meta name="google-site-verification" content="%s">' . "\n", esc_attr($code));
        }
    }

    public function tag(): void
    {
        $id = (string) $this->settings->get('analytics.tracking.measurement_id', '');

        if ($id === '' || is_preview() || is_customize_preview()) {
            return;
        }

        $track = ! ($this->settings->get('analytics.tracking.exclude_editors', true) && current_user_can('edit_posts'));

        /**
         * Filters whether the GA4 tag is printed on this request.
         *
         * @param bool   $track
         * @param string $id    Measurement ID.
         */
        if (! apply_filters('featherdash/tracking/enabled', $track, $id)) {
            return;
        }

        /**
         * Filters the Consent Mode defaults sent before the tag loads.
         * Return an empty array to send none.
         *
         * @param array<string, string|int> $defaults
         */
        $defaults = $this->settings->get('analytics.tracking.consent_mode', true)
            ? (array) apply_filters('featherdash/tracking/consent_defaults', [
                'ad_storage' => 'denied',
                'ad_user_data' => 'denied',
                'ad_personalization' => 'denied',
                'analytics_storage' => 'denied',
                'wait_for_update' => 500,
            ])
            : [];
        $consent = $defaults !== [] ? "gtag('consent','default'," . wp_json_encode($defaults) . ');' : '';

        /**
         * Filters the parameters of gtag('config'), e.g. `['debug_mode' => true]`.
         *
         * @param array<string, mixed> $config
         * @param string               $id
         */
        $config = (array) apply_filters('featherdash/tracking/config', [], $id);

        // Printed here rather than enqueued: Consent Mode defaults must come before other tags.
        wp_print_script_tag([
            'async' => true,
            'src' => esc_url('https://www.googletagmanager.com/gtag/js?id=' . rawurlencode($id)),
        ]);
        wp_print_inline_script_tag(
            'window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}'
            . $consent
            . "gtag('js',new Date());gtag('config'," . wp_json_encode($id) . ($config !== [] ? ',' . wp_json_encode($config) : '') . ');'
        );
    }

    /**
     * The Meta Pixel base code. With "Wait for cookie consent" on, consent is
     * revoked before init and granted once the visitor allows marketing
     * cookies: through the WP Consent API (Complianz, CookieAdmin, CookieYes…)
     * or Cookiebot's own callback. The <noscript> image is only printed
     * without consent handling, since it would fire before any choice.
     */
    public function metaPixel(): void
    {
        $id = (string) $this->settings->get('analytics.tracking.meta_pixel', '');

        if ($id === '' || is_preview() || is_customize_preview()) {
            return;
        }

        $track = ! ($this->settings->get('analytics.tracking.exclude_editors', true) && current_user_can('edit_posts'));

        /**
         * Filters whether the Meta Pixel is printed on this request.
         *
         * @param bool   $track
         * @param string $id    Pixel ID.
         */
        if (! apply_filters('featherdash/tracking/meta_pixel_enabled', $track, $id)) {
            return;
        }

        $consent = (bool) $this->settings->get('analytics.tracking.consent_mode', true);

        $base = "!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};"
            . "if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;"
            . "t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');";

        $grant = '';

        if ($consent) {
            $base .= "fbq('consent','revoke');";
            $grant = "(function(){var g=function(){fbq('consent','grant');};"
                . "if(typeof wp_has_consent==='function'&&wp_has_consent('marketing'))g();"
                . "document.addEventListener('wp_listen_for_consent_change',function(e){if(e.detail&&e.detail.marketing==='allow')g();});"
                . "if(window.Cookiebot&&Cookiebot.consent&&Cookiebot.consent.marketing)g();"
                . "window.addEventListener('CookiebotOnAccept',function(){if(Cookiebot.consent.marketing)g();});})();";
        }

        wp_print_inline_script_tag($base . "fbq('init'," . wp_json_encode($id) . ");fbq('track','PageView');" . $grant);

        if (! $consent) {
            printf(
                '<noscript><img height="1" width="1" style="display:none" alt="" src="%s"></noscript>' . "\n",
                esc_url('https://www.facebook.com/tr?id=' . rawurlencode($id) . '&ev=PageView&noscript=1')
            );
        }
    }

    /**
     * Meta Pixel (dataset) IDs are 10–20 digits.
     */
    public static function sanitizePixelId(mixed $value): string
    {
        $id = preg_replace('/\s+/', '', is_string($value) ? $value : '') ?? '';

        return preg_match('/^\d{10,20}$/', $id) === 1 ? $id : '';
    }

    /**
     * GA4 measurement IDs look like G-ABC123XYZ.
     */
    public static function sanitizeMeasurementId(mixed $value): string
    {
        $id = strtoupper(trim(is_string($value) ? $value : ''));

        return preg_match('/^G-[A-Z0-9]{4,20}$/', $id) === 1 ? $id : '';
    }

    /**
     * Accepts the verification code or the whole meta tag Search Console shows.
     */
    public static function sanitizeVerification(mixed $value): string
    {
        $value = trim(is_string($value) ? $value : '');

        if (preg_match('/content=["\']([^"\']+)["\']/i', $value, $match) === 1) {
            $value = $match[1];
        }

        return preg_match('/^[A-Za-z0-9_-]{10,100}$/', $value) === 1 ? $value : '';
    }
}
