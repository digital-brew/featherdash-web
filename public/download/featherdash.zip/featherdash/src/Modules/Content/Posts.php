<?php

declare(strict_types=1);

namespace DigitalBrew\Featherdash\Modules\Content;

use DigitalBrew\Featherdash\Settings\Settings;
use WP_Admin_Bar;

final class Posts
{
    public function register(Settings $settings): void
    {
        if ($settings->get('content.posts', false)) {
            return;
        }

        add_filter('register_post_type_args', [$this, 'filterPostTypeArgs'], 10, 2);
        add_filter('register_taxonomy_args', [$this, 'filterTaxonomyArgs'], 10, 3);
        add_action('admin_menu', [$this, 'removeMenus'], 999);
        add_action('admin_bar_menu', [$this, 'removeBarNodes'], 999);
    }

    /**
     * @param array<string, mixed> $args
     *
     * @return array<string, mixed>
     */
    public function filterPostTypeArgs(array $args, string $postType): array
    {
        if ($postType === 'post') {
            $args['show_ui'] = false;
            $args['show_in_menu'] = false;
            $args['show_in_admin_bar'] = false;
            $args['show_in_nav_menus'] = false;
            $args['public'] = false;
        }

        return $args;
    }

    /**
     * @param array<string, mixed> $args
     * @param array<int, string>   $objectType
     *
     * @return array<string, mixed>
     */
    public function filterTaxonomyArgs(array $args, string $taxonomy, array $objectType): array
    {
        if (in_array($taxonomy, ['category', 'post_tag'], true)) {
            $args['show_ui'] = false;
            $args['show_in_menu'] = false;
            $args['show_in_nav_menus'] = false;
            $args['public'] = false;
        }

        return $args;
    }

    public function removeMenus(): void
    {
        remove_menu_page('edit.php');
        remove_submenu_page('edit.php', 'edit-tags.php?taxonomy=category');
        remove_submenu_page('edit.php', 'edit-tags.php?taxonomy=post_tag');
    }

    public function removeBarNodes(WP_Admin_Bar $bar): void
    {
        $bar->remove_node('new-post');
    }
}
