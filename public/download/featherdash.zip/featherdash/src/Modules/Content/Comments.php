<?php

declare(strict_types=1);

namespace DigitalBrew\Featherdash\Modules\Content;

use DigitalBrew\Featherdash\Settings\Settings;

final class Comments
{
    public function register(Settings $settings): void
    {
        if ($settings->get('content.comments', false)) {
            return;
        }

        add_action('admin_init', [$this, 'redirectCommentScreens']);
        add_action('admin_menu', [$this, 'removeMenus']);
        add_action('wp_before_admin_bar_render', [$this, 'removeBarItem']);
        add_action('admin_bar_menu', [$this, 'removeNetworkBarItems'], PHP_INT_MAX - 1);

        add_filter('comments_open', '__return_false', 20);
        add_filter('pings_open', '__return_false', 20);
        add_filter('comments_array', '__return_empty_array', 10, 2);
        add_filter('get_comments_number', '__return_zero');

        add_action('init', [$this, 'removeCoreBarMenu']);
    }

    public function redirectCommentScreens(): void
    {
        global $pagenow;

        if ($pagenow === 'edit-comments.php' || $pagenow === 'options-discussion.php') {
            wp_safe_redirect(admin_url());
            exit;
        }

        remove_meta_box('dashboard_recent_comments', 'dashboard', 'normal');

        foreach (get_post_types() as $postType) {
            if (post_type_supports($postType, 'comments')) {
                remove_post_type_support($postType, 'comments');
                remove_post_type_support($postType, 'trackbacks');
            }
        }
    }

    public function removeMenus(): void
    {
        remove_menu_page('edit-comments.php');
        remove_submenu_page('options-general.php', 'options-discussion.php');
    }

    public function removeCoreBarMenu(): void
    {
        if (is_admin_bar_showing()) {
            remove_action('admin_bar_menu', 'wp_admin_bar_comments_menu', 60);
        }
    }

    public function removeBarItem(): void
    {
        global $wp_admin_bar;

        if ($wp_admin_bar instanceof \WP_Admin_Bar) {
            $wp_admin_bar->remove_menu('comments');
        }
    }

    public function removeNetworkBarItems(\WP_Admin_Bar $bar): void
    {
        foreach (get_blogs_of_user(get_current_user_id()) as $site) {
            $bar->remove_node("blog-{$site->userblog_id}-c");
        }
    }
}
