# FAQ & troubleshooting

**The admin looks like standard WordPress.**
Check **Appearance → Enable admin theme**. Clear any page/asset cache and hard-reload (Ctrl+Shift+R).

**A plugin page looks broken.**
Turn the admin theme off briefly: if the page still looks broken, it's the plugin. If not, report it with the plugin name, page URL and a screenshot. See [compatibility](compatibility.md).

**I hid a menu item but users can still open the page.**
Hiding in the [menu builder](menu-builder.md) is visual only. Use roles/capabilities (or a membership/role plugin) to restrict access.

**A plugin's toolbar item disappeared.**
With Pro, **Toolbar → Visible toolbar items added by plugins** decides which plugin items show. Every item stays until you untick one; after that, only ticked items show, so tick it again. Same for plugin dashboard widgets under **Dashboard** (Pro). Without Pro, plugin items and widgets are left alone.

**A plugin's dashboard widget isn't in the list.**
Open the Dashboard once; widgets are recorded when a plugin adds them.

**Plugin columns are missing from Post type columns.**
Open that list screen once (e.g. Products); columns are recorded when the plugin adds them.

**Page prefetch or transitions don't seem to work.**
Prefetch needs a Chromium browser (Chrome, Edge, Brave…); transitions work in Chromium and Safari and are off when the system asks for reduced motion.

**The GA widget says it's not configured.**
Follow [Analytics → Connection](analytics.md) and use **Test connection**. The most common causes: the Data API isn't enabled in Google Cloud, or the service-account email wasn't added as a Viewer to the GA4 property.

**Visits are counted twice in GA4.**
Another plugin or Tag Manager also adds the GA tag. Clear the Measurement ID in FeatherDash or remove the other tag.

**No social tags appear.**
An SEO plugin (Yoast, SEOPress, Rank Math, All in One SEO) is active, so FeatherDash leaves social tags to it.

**I'm locked out by maintenance mode.**
Log in at `/wp-login.php` — the login screen is never blocked. Users who can edit posts see the site normally.

**WordPress doesn't update itself any more.**
**Admin clean-up → Turn off automatic updates** is on (in agency mode they're always off). Untick it, or update through your usual process.

**How do I move my setup to another site?**
[Tools](tools.md) → Export to JSON → on the other site, Import from JSON → Import settings.

**How do I remove everything?**
Deactivate and delete the plugin: uninstalling removes FeatherDash's settings, menu layout and recorded lists.
