# Maintenance

Show visitors a holding page while you work on the site.

| Setting | Default | What it does |
| --- | --- | --- |
| Turn on maintenance mode | Off | Visitors see the maintenance page instead of the site. |
| Title | "We'll be back soon" | Main heading; also the browser tab title. |
| Subtitle | "We're doing some scheduled maintenance." | A short line under the title. |
| Body | — | Optional longer text (expected return, contact). Line breaks kept; basic HTML allowed. |
| Background colour | `#1e1e1e` | Page background. With an image it becomes a tint over the image. |
| Background image (Pro) | — | Covers the whole page behind the text. |
| Text colour | `#ffffff` | Colour of the title, subtitle and body. |

## Who sees what

- **Logged-out visitors** and logged-in users who **can't edit content** (e.g. customers) get the maintenance page, sent with a **503** status and a `Retry-After` header — search engines come back later instead of dropping your pages.
- **Anyone who can edit posts** (contributors and up, shop managers) sees the site normally, with a red **Maintenance mode** badge in the toolbar.
- The admin, the login screen, the REST API, AJAX and cron keep working.

## Preview

**Preview the maintenance page** (bottom of the card) opens `/?fd-maintenance-preview=1`. It works for administrators at any time, even while maintenance mode is off. Save first.
