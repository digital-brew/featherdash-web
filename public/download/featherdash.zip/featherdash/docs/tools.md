# Tools

Back up, copy and reset all FeatherDash settings — including the menu builder layout.

## Export

- The **Export all FeatherDash settings** box shows every setting as JSON.
- **Copy** (above the box) puts it on the clipboard.
- **Export to JSON** (below the box) downloads it as `featherdash-<site>-<date>.json`.

## Import

1. Put the JSON in the **Import all FeatherDash settings** box:
   - **Paste** (above the box) reads the clipboard (your browser may ask for permission; otherwise paste with Ctrl+V), or
   - **Import from JSON** (next to *Import settings*) loads a `.json` file — invalid files are rejected and the box stays as it was.
2. Click **Import settings**. All current settings are replaced.

Imported values go through the same checks as the settings form; unknown or invalid values are ignored.

## Reset

**Reset all settings to defaults** (right-hand link) restores every setting and the default menu layout after a confirmation. It can't be undone — export first.

## Not included in export

- The **Site Icon** (it's WordPress' own setting).
- Google Analytics credentials (they live in `wp-config.php` / `.env`).
- Per-user sidebar choices and per-page Social sharing values.
