# Toolbar

The black bar at the top of the admin and (for logged-in users) the website.

## Visible core toolbar items

Tick the WordPress items to show; unticked items are removed in the admin and on the front end. Default: **Site name, Edit, My account, Search**.

Available: WordPress logo menu, Site name, Edit site (block themes), Comments, New content, Customize, Archive / search, Edit, My account, Updates, Search, Widgets.

The mobile menu button and the Ctrl+K command palette always stay.

## Visible toolbar items added by plugins (Pro)

Plugins often add their own menus (SEO, analytics, caches, store badges). Only ticked ones are shown; every other plugin item is removed. **All of them stay until you untick one.** In [agency mode](developers.md) the default is **Kinsta Cache** only.

- Items of plugins that aren't active are greyed out; you can still tick them in advance.
- Plugins not in the list are added automatically the first time their item appears in the toolbar (open a few admin pages).
- FeatherDash's own live visitors counter and maintenance badge have their own settings.

Known items: Kinsta (Clear Caches), Gravity Forms (Forms), MonsterInsights (Insights), SEOPress (SEO), Yoast SEO (SEO), The Events Calendar (Events), WooCommerce (Store coming soon badge), Query Monitor.

## Other settings

| Setting | Default | What it does |
| --- | --- | --- |
| Show toolbar on the front end for administrators | On | Each user's own profile setting can still turn it off. |
| Show toolbar on the front end for other roles | On | Editors, shop managers, customers… |
| Show display name instead of "Howdy, …" | On | Just the user's name. |
| Account menu position | Toolbar | **Pro.** *Bottom of the sidebar* pins your name and avatar to the bottom of the sidebar (just the avatar when it's collapsed), with the account card opening upwards, and turns the Ctrl+K command palette into a "Search" field in the middle of the toolbar. Phones keep the account in the toolbar. |

## Network admin

Shown on multisite installs only.

| Setting | Default | What it does |
| --- | --- | --- |
| Hidden network items | None | Ticked items are removed from the Network Admin menu. Available: **Dashboard → Updates**. |

## Account menu

Click your name (top right) to open the account card:

- the site (icon or initials, name, domain) — links to the website
- you (avatar, name, email)
- **Edit profile**
- **Theme** (Pro): Default / Modern / Light, for you only
- **Log out**

The card opens on click (Enter/Space from the keyboard) and closes on Escape or a click outside.
