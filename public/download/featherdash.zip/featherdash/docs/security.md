# Security

| Setting | Default | What it does |
| --- | --- | --- |
| Enable XML-RPC | On | XML-RPC is an old remote-publishing API bots use for password guessing. Keep it off unless something needs it (Jetpack, old mobile apps). |
| Hide REST `/wp/v2/users` from logged-out visitors | Off | Stops visitors listing your users (and login names) through the REST API. |
| Block `?author=N` enumeration | Off | Redirects `?author=1`-style URLs to the homepage so bots can't discover usernames. Author archive pages keep working. |

The two login-screen settings (language switcher, logo link) are on the [Login](login.md) tab.
