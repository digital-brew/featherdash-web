# Front end

Settings that change what the website itself loads.

## Head clean-up

| Setting | Default | What it does |
| --- | --- | --- |
| Load emoji scripts | On | Off: removes WordPress' emoji detection script and styles. Modern browsers show emoji without them. |
| Enable RSS feeds | On | Off: feed links are removed from the page head and feed URLs redirect to the homepage. |
| Keep generator/RSD/WLW/shortlink/REST/oEmbed links in `<head>` | On | Off: removes those tags (WordPress version, RSD and Windows Live Writer links, shortlink, REST and oEmbed discovery). |
| Strip `?ver=` from asset URLs | Off | Removes the WordPress version from CSS/JS URLs. Plugin and theme versions are kept. |
| Enable oEmbed JS | On | Off: removes the script that lets other WordPress sites embed your posts. Embedding YouTube, X etc. in your content still works. |
| Remove DNS-prefetch hints | Off | Removes the DNS-prefetch hint for the emoji image server (s.w.org). |

## jQuery

| Setting | Default | What it does |
| --- | --- | --- |
| Load jQuery on the front end | On | Turn off only if your theme and plugins don't need it — it can break sliders, forms and similar features. |
| Load jQuery Migrate | On | Keeps old jQuery code working. Most modern themes don't need it. |
| Serve jQuery from a CDN | Off | **Pro.** Loads jQuery from code.jquery.com. Usually slower than self-hosting and sends visitor IPs to a third party. |
