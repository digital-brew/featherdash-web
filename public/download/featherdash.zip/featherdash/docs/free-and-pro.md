# Free and Pro

FeatherDash is free on WordPress.org. **FeatherDash Pro** adds the tools agencies use to hand a site over. Pro settings appear in place with a small **Pro** pill; without Pro they're shown but can't be changed, and saved values are kept (they come back when Pro is activated).

| Area | Free | Pro |
| --- | --- | --- |
| Admin theme | Dark frame, content card, Inter, accent colour, accordion submenus, block-editor accent, navigation speed, footer | Modern and Light themes, per-user theme switch |
| Menu builder | — | Drag-and-drop menu builder |
| Toolbar | Visible core items, front-end toolbar, Howdy, account card | Hide toolbar items added by plugins, account menu at the bottom of the sidebar with a search field in the toolbar |
| Dashboard | Visible core widgets, welcome widget | Hide plugin widgets, Site analytics widget, welcome widget per role, request widget (email and Slack) |
| Content & tables | Comments/posts off, Users columns, wide tables scroll sideways | Post type columns (order, hide, sort, ACF), WooCommerce purchased products |
| Admin clean-up | Help tabs, Screen Options, update nags, admin email check, “saved” messages as pop-ups, Appearance screens, automatic updates | Admin notice manager, with notifications in the toolbar |
| Front end, Security | Everything else | jQuery from a CDN |
| Login | Logo, background colour, accent | Background image, message |
| Maintenance | Everything else | Background image |
| Analytics | GA4 tag, Consent Mode, Meta Pixel, Search Console | GA4 dashboard widget, live visitors |
| White label | — | Brand name, sidebar logo, settings access, hide FeatherDash |
| Site identity | Favicon | Open Graph & X cards |
| Tools | Export, import, reset | — |

Licences, updates and checkout run through Freemius. Pro keeps working after a yearly licence expires; it just stops updating.
