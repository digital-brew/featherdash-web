# Menu builder (Pro)

**Settings → FeatherDash → Menu builder** rebuilds the admin sidebar by drag and drop.

## What you can do

- **Reorder** any item and **move** submenu items under another parent.
- **Nest up to four levels.** WordPress itself shows two; FeatherDash renders levels 3–4 as collapsible groups inside the submenu.
- **Rename** items and **change icons** (Dashicons, or your own SVG).
- **Add custom links** (any URL, optionally opening in a new tab) at any level.
- **Add labels**: at the top level a label is a section heading (e.g. "Administration"); inside a submenu it groups the items nested under it and can be clicked to expand them.
- **Add separators.**
- **Hide** an item for everyone or for specific roles.

Save to apply; *Reset* returns to the default layout.

## Good to know

- **Hiding is visual only.** A hidden page still opens by its URL, keeps its page title and permission checks. Use roles/capabilities to restrict access.
- **Moved plugin pages keep working**: the item opens the plugin's page and the right parent is highlighted.
- **A section's own first page** (e.g. *Settings → General*) can't be moved under another parent — WordPress would then deny access to the section.
- **New plugins**: menu items from plugins installed later appear in their default position until you place them.
- The layout is stored separately from the other settings (`featherdash_menu`) but is included in **Tools → Export**.
- With no saved layout, FeatherDash starts from WordPress' own menu with *Administration* and *Development* labels.
