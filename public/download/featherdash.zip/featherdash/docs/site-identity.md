# Site identity

## Favicon

The icon in browser tabs, bookmarks and on phone home screens — on the website, in the admin and on the login screen.

This field **is** WordPress' own **Site Icon** — the same one as in Appearance → Customize → Site Identity. Changing it here changes it there too, and WordPress generates every size from it. Use a **square image of at least 512 × 512 px** (FeatherDash doesn't crop).

## Open Graph & social (Pro)

Controls how pages look when shared on Facebook, LinkedIn, X and in messaging apps.

| Setting | Default | What it does |
| --- | --- | --- |
| Add Open Graph and X card tags | On | Adds `og:title`, `og:description`, `og:image`, `og:url`, `og:site_name`, `og:locale`, article times and the matching `twitter:` tags to every page. |
| Per-page share details | Off | Adds the **Social sharing** box to the editor sidebar (see below). |
| Default share image | — | For pages without their own share image or featured image, and for the homepage and archives. 1200 × 630 px works best. |
| Homepage title | — | Title when the homepage is shared. Empty = site name (or the front page's own Social sharing title). |
| Homepage description | — | Empty = site tagline (or the front page's own description). |
| X card style | Large image | Large image above the title, or a small square beside it. |
| X (Twitter) username | — | The site's @username, credited on shared cards. |
| Facebook App ID | — | Only for Facebook Insights on shared links. |

### Per page: the "Social sharing" box

With **Per-page share details** on, every page, post, product and other public post type gets a **Social sharing** box in the editor sidebar with its own **title**, **description** and **image**. Empty fields fall back to: page title → excerpt (or the start of the content) → featured image → default share image.

With it off, every page uses those fallbacks. Values saved in the box are kept and apply again when it's turned back on.

### SEO plugins

While **Yoast SEO, SEOPress, Rank Math or All in One SEO** is active, FeatherDash adds no social tags (they would be duplicated) and the settings card says which plugin is in charge. Edit social tags in that plugin instead.
