# Content & tables

## Content

| Setting | Default | What it does |
| --- | --- | --- |
| Enable comments | On | Off: comments switched off site-wide — forms close, existing comments are hidden, the Comments menu, toolbar icon and dashboard box go. |
| Enable Posts | On | Off: the blog Posts section (with Categories and Tags) is hidden from the menu, toolbar and nav-menu screen. Existing posts stay and still load on the front end. |

## Users table

| Setting | Default | What it does |
| --- | --- | --- |
| Add columns | None | Extra columns on the Users screen ("Last login" needs the next setting). Both sortable. |
| Remove columns | none | Username, Name, Email, Role, Posts. |
| Record last login time | Off | Saves each user's last login time. |

## Post type columns (Pro)

One block per post type with a list screen (Pages, Posts, Products, Events, custom post types…). Each block is a single list of **Columns**:

- **Drag** the handle to set the order. The checkbox column always stays first.
- **Tick** to show a column, untick to hide it. *Title* (*Name* for products) can be moved but not hidden — it holds the row actions.
- **Sort icon** (right): allow sorting the list by that column. Greyed out where there's nothing to sort by (categories, most plugin columns).
- Tags show where extra columns come from:
  - **FeatherDash**: Featured image, ID, Slug, Last modified, Template (pages/templated types), Order (types with page attributes), Total sales (products)
  - **ACF**: every top-level field of the ACF field groups assigned to that post type

### ACF columns

Values are shown readably by field type: text and numbers, choices (labels), yes/no, dates, links and URLs, emails, colour swatches, images as thumbnails, files, related posts, terms and users. Repeaters, groups, flexible content, galleries and layout fields aren't offered.

Sortable ACF types: text, number, range, email, URL, select/radio/button group (single), true/false, date, date-time, time, colour.

### Good to know

- Columns some plugins add only on their own list screen (WooCommerce, SEOPress, Yoast) appear here after you've opened that list once.
- Sorting that WordPress or a plugin already offers stays on unless you turn it off; FeatherDash's extra columns are sortable by default; *Author* becomes sortable when you turn it on.
- New columns (from a plugin added later) appear next to the column they naturally follow.

## WooCommerce (Pro)

| Setting | Default | What it does |
| --- | --- | --- |
| Orders: add columns → Purchased products | Off | A column listing the products in each order (quantity × name), for both order storage modes (HPOS and legacy). |
