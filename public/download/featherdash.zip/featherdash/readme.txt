=== FeatherDash ===
Contributors: digitalbrew
Tags: admin theme, admin, dashboard, clean up, login
Requires at least: 6.8
Tested up to: 7.1
Requires PHP: 8.2
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A modern, calm wp-admin: clean admin theme, tidy toolbar, branded login, maintenance mode and admin clean-up in one plugin.

== Description ==

**FeatherDash turns wp-admin into a clean, modern, branded workspace — in minutes, on every site.**

Built by an agency for client handover: fewer menus, no clutter, a login screen with your logo, and an admin that feels fast.

Out of the box FeatherDash only changes the look: the admin theme, your accent colour and a tidier toolbar. Everything else — clean-up, front-end and security options — stays as WordPress has it until you switch it on.

= A modern admin theme =

* Dark frame with a rounded content card, the Inter font and your accent colour
* Accordion submenus (or hover flyouts)
* Pages load on hover and fade in — the admin feels instant
* A proper mobile drawer on phones
* A layer on top of WordPress' own styles: the block editor and plugins keep working

= Show only what matters =

* Choose which WordPress toolbar items are visible
* Choose which core dashboard widgets show, and add a welcome widget for clients
* Hide Help tabs, Screen Options and update notices for non-administrators
* Turn off Appearance screens you don't use (Themes, Customizer, Widgets, Patterns…)
* Turn comments or blog posts off site-wide
* Last login and registration date columns on the Users screen
* "Saved" messages as pop-ups

= Ready for handover =

* Branded login screen: logo and colours
* Maintenance mode with a proper 503 page, preview and editor bypass
* Favicon (Site Icon) from the settings
* GA4 tag with Google Consent Mode, Search Console verification and the Meta Pixel

= Faster, leaner front end =

* Remove emoji scripts, feed links, generator and other head tags, version strings
* Control jQuery and jQuery Migrate

= Security basics =

* Turn off XML-RPC, hide REST users from visitors, block ?author= scans

= Set it up once =

* Export and import all settings as JSON (copy, paste or file)

= FeatherDash Pro =

Everything agencies need on top: a **4-level drag-and-drop menu builder**, **Modern and Light themes** with a per-user theme switch, **hide toolbar items, dashboard widgets and admin notices added by plugins**, **post type columns** (order, hide, sort, add featured image, ID, slug or **ACF fields**), a **GA4 dashboard widget with live visitors**, a client **request widget** (email and Slack), **white label**, login background image and message, and **Open Graph / X cards** with a per-page editor. [Learn more](https://featherdash.io/#pricing)

== Installation ==

1. Plugins → Add New → search "FeatherDash" → Install → Activate.
2. Open **Settings → FeatherDash** and go through the tabs.
3. Optional: Tools → Export to JSON, then import the file on your next site.

With Composer (Bedrock): `composer require wp-plugin/featherdash`. See the [documentation](https://featherdash.io/docs/developers/).

== Frequently Asked Questions ==

= What changes when I activate it? =
Only the look: the admin theme, the accent colour and a tidier toolbar. Clean-up, front-end and security options stay off until you choose them in Settings → FeatherDash.

= Will it break my admin or the block editor? =
No. FeatherDash never removes WordPress' own stylesheets; it adds a layer on top. The block editor only picks up your accent colour. Turn the theme off at any time and every other setting keeps working.

= Does it work with WooCommerce, Yoast, ACF, Gravity Forms…? =
Yes — FeatherDash was checked page by page with 40+ popular plugins, on desktop and mobile. See the compatibility list in the [documentation](https://featherdash.io/docs/).

= Does it contact external servers? =
Only for features you switch on, and Freemius only if you opt in. See "External services" below.

= Does it change the front end of my site? =
Only the optional head clean-up, feed redirects, jQuery, security options (the `?author=` redirect, hiding the REST users endpoint from visitors), maintenance mode, favicon and tracking tags — each with its own setting.

= What happens to my settings if I deactivate it? =
They stay in the database until you uninstall the plugin; uninstalling removes them.

== External services ==

FeatherDash connects to these services only in the cases listed.

= Freemius =
Handles the optional usage statistics and the upgrade to Pro. With your opt-in (asked once after activation, and you can skip it), it sends your site URL, WordPress, PHP and plugin versions and the admin's name and email to Freemius. Nothing is sent if you skip. [Terms](https://freemius.com/terms/) · [Privacy policy](https://freemius.com/privacy/)

= Google tag (gtag.js) =
When you enter a GA4 Measurement ID (Settings → FeatherDash → Analytics), visitors' browsers load the Google tag from googletagmanager.com and send page views to Google Analytics, with Consent Mode defaults set to "denied" until the visitor agrees. [Terms](https://marketingplatform.google.com/about/analytics/terms/us/) · [Privacy policy](https://policies.google.com/privacy)

= Meta Pixel =
When you enter a Pixel ID, visitors' browsers load the Pixel from connect.facebook.net and send page views to Meta (browsers without JavaScript load a tracking image from www.facebook.com/tr instead); with "Wait for cookie consent" on, only after the visitor allows marketing cookies. [Terms](https://www.facebook.com/legal/terms) · [Privacy policy](https://www.facebook.com/privacy/policy/)

The Search Console verification code is only a meta tag on your home page; FeatherDash doesn't contact Google for it.

== Screenshots ==

1. Dashboard with the FeatherDash admin theme
2. Settings → FeatherDash with vertical tabs and help text for every setting
3. Choose visible toolbar items
4. Choose visible dashboard widgets
5. Branded login screen
6. Maintenance page
7. Mobile admin drawer

== Changelog ==

= 1.1.0 =
* Free and Pro editions. The free plugin only changes the look until you choose other settings.
* Welcome widget for clients, "saved" messages as pop-ups, row actions menu, Appearance screen toggles, Meta Pixel, Search Console verification, favicon, About tab.
* WooCommerce screens follow the admin theme; wide list tables scroll sideways.
* Full list: https://featherdash.io/docs/changelog/

= 1.0.0 =
* Rewrite: database-only settings, admin theme as a layer on top of core styles, plain CSS and vanilla ES modules.
